import { StockdashboardPage } from './app.po';

describe('stockdashboard App', () => {
  let page: StockdashboardPage;

  beforeEach(() => {
    page = new StockdashboardPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
