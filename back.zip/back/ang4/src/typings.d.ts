/* SystemJS module definition */
declare var Client:any;
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
