import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable'
import * as io from 'socket.io-client'
@Injectable()
export class SocketService {
private  url="http://localhost:3000";
private socket;
  constructor() { 
    this.socket =io(this.url);
  }
  sendMessage(message){
    // message.socketId=this.socket.socketId
    // console.log("inside send messaAGAW")
  this.socket.emit('addMessage',message)
  //  console.log("am   i  sneding your message")

}
getcomputedata(){
  let observable=new Observable(observer =>{
    this.socket.on('computedData', (data)=>{
      // console.log("return to service",data);
      observer.next(data);
    });
    return () =>{
      this.socket.disconnect();
    };
  })
  return observable
}
sendvisitor(visitorData){
  // console.log("i am ready to send data ",visitorData)
  this.socket.emit("visitorData",visitorData);
  // console.log(" i think  io have done my work")
}
  getMessage () {
    let observable =new Observable(observer => {
      // this.socket =io(this.url);
      this.socket.on('message',(data)=>{
        observer.next(data);
      });
      return () => {
        this.socket.disconnect();
      };
    })
    return observable;
  }

}
