import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {SocketService} from './socket.service'
import { NvD3Module } from 'ng2-nvd3';

import { AppComponent } from './app.component';
import 'd3';
import 'nvd3';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,NvD3Module
  ],
  providers: [SocketService],
  bootstrap: [AppComponent]
})
export class AppModule { }
