import { Component, OnInit, ViewChild } from '@angular/core';
import { SocketService } from './socket.service'
import * as Client from 'ClientJs';

import 'd3';
import 'nvd3';
declare let d3: any;
declare let nvd3: any;

@Component({

  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [
    '../../node_modules/nvd3/build/nv.d3.css'
  ],
  // encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  @ViewChild('nvd3') nvd3;
  options;
  data;
  browserOptions;
  browserData=[];
  count = 0;
  liveUser=0;

  // socket.emit('visitor-data', visitorData);
  ngOnInit() {

    this.sendMessage();

    this.browserOptions={
         chart: {
            color:["red","green","blue"],
              donutRatio:.1,
                type: 'pieChart',
                height: 500,

                x: function(d){return d.key;},
                y: function(d){return d.y;},
                showLabels: true,
                transitionDuration: 500,
                labelThreshold: 0.01,
                legend: {
                    margin: {
                        top: 5,
                        right: 35,
                        bottom: 5,
                        left: 0
                    }
                }
            }
    }
    this.browserData= [
          {
                key: "Chrome",
                y: 100
            }
            ]
    this.options = {
      chart: {
        // yRange:[0,10,20],
        forceY:[0],
        type: 'lineChart',
        height: 450,
        width: 500,
        // color:'#fff',
        margin: {
          top: 20,
          right: 20,
          bottom: 40,
          left: 55
        },
        x: function (d) { return d.x; },
        y: function (d) { return d.y; },
        // useInteractiveGuideline: true,
        dispatch: {
          stateChange: function (e) { console.log("stateChange"); },
          changeState: function (e) { console.log("changeState"); },
          tooltipShow: function (e) { console.log("tooltipShow"); },
          tooltipHide: function (e) { console.log("tooltipHide"); }
        },
        xAxis: {
          axisLabel: 'Time (ms)'
        },
        yAxis: {
          axisLabel: 'Voltage (v)',
          tickFormat: function (d) {
            return d3.format('.02f')(d);
          },
          axisLabelDistance: -10
        },
        callback: function (chart) {
          console.log("!!! lineChart callback !!!");
        }
      }
    }
    this.data = [

      {

        color: "#abcdef",
        key: "line Chart",
        values: [
          {
            x: 1,
            y: 0
          }
        ]
      }
    ]

    this.getcomputedData();

    // this.getMessage();

    //  this.sendMessage();
    // let ref = this
    // ref.datachanger.bind(this)()
    // this.datachanger()
  }
  ngAfterViewInit() {
    // crop();
    // this.sendMessage ()

  }
  // let count =1



  xval = 2
  datachanger(data,timer) {
    // this.nvD3.chart.update()
    // console.log("i ma inside darachacjfafml")
// console.log(this.nvd3);
    // console.log("i ma inside darachacjfafml")
    if (this.data[0].values.length > 10) {
      this.data[0].values.shift()
    }
 
    if(data){
      this.data[0].values.push({
      x: this.xval++,
      y: data
    });
    }else{
      this.data[0].values.push({
      x: this.xval++,
      y:this.data[0].values[this.data[0].values.length-1].y
    });
    }
    
    this.nvd3.chart.update()

return timer;

  }






  // private Client:any
  // title = 'app';
  constructor(private socketService: SocketService) {

  }
  // visitorData = {
  // 	referringSite: document.referrer,
  // 	page: location.pathname
  // }
  getcomputedData() {
      let timer:any
    this.socketService.getcomputedata().subscribe(data => {
      console.log("initial data come here",data["browser"]);




      this.browserData=[]

      for (var browsername in data["browser"]) {
        
          let value = data["browser"][browsername];
          console.log("only count come here ",browsername,value)
          var flag=true;
          this.browserData.forEach(obj => {
            console.log(this.browserData)
            if(obj["key"]===browsername){
              // console.log("helloooooooooooooooooooo")
              obj["y"]=value
              flag=false;
              

            }
            // obj["key"]="mozila",
            // obj["y"]=15
            console.log("After karyakaram",this.browserData.length)
          });
          if(flag){
           
                console.log("inside end point condition")
              let newObj={
                "key":browsername,
                "y":value
              }
              this.browserData.push(newObj)
            
          }

            console.log("After karyakaram 2",this.browserData)
        
      }






















      // for (var browsername in data["browser"]) {
        
      //     let value = data["browser"][browsername];
      //     console.log("only count come here ",browsername,value)
      //     this.browserData.forEach(obj => {
      //       console.log(this.browserData)
      //       if(obj["key"]===browsername){
      //         alert("helloooooooooooooooooooo")
      //         obj["y"]=value
      //       }else{
      //         let newObj={
      //           "key":browsername,
      //           "y":value
      //         }
      //         this.browserData.push(newObj)
      //       }
      //       // obj["key"]="mozila",
      //       // obj["y"]=15
      //       console.log("After karyakaram",this.browserData.length)
      //     });
      //       console.log("After karyakaram 2",this.browserData.length)
        
      // }



      // console.log("browser",data["browser"]);
      // for (let nameBro in data["browser"]) {
      //             console.log("this browser data client",this.browserData)
        
      //   console.log("kewew",nameBro)
      //   if (data["browser"].hasOwnProperty(nameBro)) {
      //     let value = data["browser"][nameBro];
      //     console.log("initial value " ,nameBro,value)
      //     // this.browserData.forEach(browserobject => {
      //       let limit=this.browserData.length
      //       for (let  index = 0; index <limit ; index++) {
      //         let browserobject = this.browserData[index];
              
            
      //       console.log("broser object from ",browserobject)
      //         if (browserobject.hasOwnProperty("key")) {

      //           var ourBro = browserobject["key"];
      //           if(ourBro==nameBro){
      //             // debugger
      //             // console.log("our bro ",ourBro)
      //             // console.log("nameBro",nameBro)
      //             browserobject["y"]=value;
      //             // delete browserobject
      //             // console.log("after update", browserobject)
      //           }else{
      //             // debugger
      //             let newBrowserobj={
      //               "key":nameBro,
      //               "y":value
      //             }
      //             // console.log("i came here accidently")
      //             this.browserData.push(newBrowserobj)
      //             // console.log("i came here ")
      //           }
      //           console.log("after iteration ",this.browserData)
      //         }
            
      //     };
     
      // //  console.log(this.browserData)
      //   }
      // }
      // this.browserData=
      this.liveUser=data["usersTotal"];
      console.log("live user",this.liveUser)
      // console.log("data to the component" ,data["usersTotal"])
      timer=this.datachanger(data["usersTotal"],timer)
      clearInterval(timer)
      let ref=this
    timer=  setInterval(function () {
        ref.datachanger(NaN,0)      },1000)
    })
  }
  getMessage() {
    //  let visitorData = {
    // 		referringSite: document.referrer,
    // 		page: location.pathname
    // 	}

    this.socketService.getMessage().subscribe(data => {
      console.log(data);
    })

  }

  sendMessage() {
    let client = new Client();
    // console.log(client)
    let visitorData = {
      browser: client.getBrowser(),
      referringSite: document.referrer,
      page: location.pathname
    }
    // console.log("i come here ",visitorData)
    this.socketService.sendvisitor(visitorData);
  }

}
